package com.example.drinkmixer;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.rpc.context.AttributeContext;


public class MainMenuAdapter extends RecyclerView.Adapter<MainMenuAdapter.MyViewHolder> {

    Context context;
    ViewGroup parent;

    public MainMenuAdapter(Context ct) {

        context = ct;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup _parent, int viewType) {

        parent = _parent;
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.listitem, parent, false);

        return new MyViewHolder(view);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.button.setText(MainActivity.DrinkNames.get(position).replace('_', ' '));
        holder.button.setOnClickListener(v -> {
            MainActivity.SendOut(position);
        });
    }

    @Override
    public int getItemCount() {
        return MainActivity.DrinkNames.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        Button button;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            button = itemView.findViewById(R.id.button);
            button.setTextColor(Color.rgb(255,255,255));
            button.setBackgroundColor(Color.rgb(55,55,55));
        }
    }
}
