package com.example.drinkmixer;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import static com.example.drinkmixer.App.random_drink;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class RandomPijacaButton extends AppCompatActivity {

    String[] drinks;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.random_drink_layout);
        new GetRandomDrink().execute();

        Button back = findViewById(R.id.back);

        back.setOnClickListener(v -> finish());

        while(random_drink == null){

        }

        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(random_drink);
            JSONObject jsonObject = (JSONObject) obj;
            drinks = (String[])((JSONArray) jsonObject.get("drinks")).toArray(new String[0]);
            final FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference ref = database.getReference("drink/make");
            ref.setValue(1);
            for (String s :
                    drinks) {
                ref = database.getReference("drink/" + MainActivity.drinks.indexOf(s));
                ref.setValue(100);
            }
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        System.out.println("Preparing " + String.join(", ",drinks));

        TextView tv = findViewById(R.id.random_text_view);
        tv.append("Preparing " + String.join(", ",drinks));


    }
}
class GetRandomDrink extends AsyncTask<String, String, String> {


    @Override
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL("https://iuz32hym3zxhbhaoykodt5vy6u0pczbn.lambda-url.eu-north-1.on.aws/calc?random=true&x=3");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            String output;
            System.out.println("Output from Server .... \n");
            output = br.readLine();
            conn.disconnect();
            random_drink = output;
            return output;
        }catch(Exception e){
            return "0";
        }
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);



    }

}