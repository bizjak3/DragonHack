package com.example.drinkmixer;

import android.app.Application;

public class App extends Application {

    public static String random_drink;

}
