package com.example.drinkmixer;

import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JsonReader {

    public static void main(String[] args) {

        JSONParser parser = new JSONParser();

        try {

            Object obj = parser.parse(new FileReader(""));

            JSONObject jsonObject = (JSONObject) obj;

            JSONObject premadeDrinks = (JSONObject) jsonObject.get("premade_drinks");

            String[] binaryBuzzIngredients = (String[])((JSONArray) premadeDrinks.get("Binary_Buzz")).toArray(new String[0]);
            String[] codeCoolerIngredients = (String[])((JSONArray) premadeDrinks.get("Code_Cooler")).toArray(new String[0]);
            String[] siliconSipperIngredients = (String[])((JSONArray) premadeDrinks.get("Silicon_Sipper")).toArray(new String[0]);
            String[] byteBreezeIngredients = (String[])((JSONArray) premadeDrinks.get("Byte_Breeze")).toArray(new String[0]);
            String[] dataDaiquiriIngredients = (String[])((JSONArray) premadeDrinks.get("Data_Daiquiri")).toArray(new String[0]);
            String[] algorithmicAmbrosiaIngredients = (String[])((JSONArray) premadeDrinks.get("Algorithmic_Ambrosia")).toArray(new String[0]);


            // do something with the ingredients arrays

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}