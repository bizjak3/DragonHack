package com.example.drinkmixer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static List<List<String>> items = new ArrayList<>();
    public static List<String> DrinkNames = new ArrayList<>();// = new String[]{"Binary_Buzz", "Code_Cooler","Silicon_Sipper","Byte_Breeze","Data_Daiquiri","Algorithmic_Ambrosia"};
    public static List<String> drinks;
    RecyclerView MainMenuRecyclerView;
    public static MainActivity Instance;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Instance = this;

        Button randomPijacaButton = (Button)findViewById(R.id.randomPijacaButton);
        Button chooseDrinkButton = (Button)findViewById(R.id.chooseDrinkButton);
        randomPijacaButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, RandomPijacaButton.class)));
        chooseDrinkButton.setOnClickListener(v -> startActivity(new Intent(this, ChooseDrink.class)));
        //sm teu nrdit za dodajanje custom napitkou, samo je zmanklo volje.
        Connect();
        try{
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApiKey("AIzaSyAQ08OHgV3sYeyjJvyyln5FXV73mm2YU8Q")
                    .setDatabaseUrl("https://drinkmixer-bf89e-default-rtdb.europe-west1.firebasedatabase.app/")
                    .setApplicationId("drinkMixer")
                    .build();
            FirebaseApp.initializeApp(Instance, options);

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    void Connect(){

            new DownloadFromAPI().execute();



    }
    public void neki(String ja){
        if(ja.equals("0")){
            ((TextView)findViewById(R.id.ErrorText)).setText("Napaka");
        }else{
            JSONParser parser = new JSONParser();

            try {

                Object obj = parser.parse(ja);
                JSONObject jsonObject = (JSONObject) obj;

                JSONObject premadeDrinks = (JSONObject) jsonObject.get("premade_drinks");
                drinks = new ArrayList<>();
                drinks.addAll(((JSONArray) jsonObject.get("drink_choice")));
                for (Object name:premadeDrinks.keySet().toArray()) {
                    DrinkNames.add((String)name);
                }
                /*String[] binaryBuzzIngredients = (String[])((JSONArray) premadeDrinks.get("Binary_Buzz")).toArray(new String[0]);
                String[] codeCoolerIngredients = (String[])((JSONArray) premadeDrinks.get("Code_Cooler")).toArray(new String[0]);
                String[] siliconSipperIngredients = (String[])((JSONArray) premadeDrinks.get("Silicon_Sipper")).toArray(new String[0]);
                String[] byteBreezeIngredients = (String[])((JSONArray) premadeDrinks.get("Byte_Breeze")).toArray(new String[0]);
                String[] dataDaiquiriIngredients = (String[])((JSONArray) premadeDrinks.get("Data_Daiquiri")).toArray(new String[0]);
                String[] algorithmicAmbrosiaIngredients = (String[])((JSONArray) premadeDrinks.get("Algorithmic_Ambrosia")).toArray(new String[0]);*/
                for (int i = 0; i < 6; i++) {
                    items.add(Arrays.asList((String[]) ((JSONArray) premadeDrinks.values().toArray()[i]).toArray(new String[0])));
                }
                /*ListView ls = findViewById(R.id.listView);
                String[] s = new String[]{"Binary_Buzz", "Code_Cooler","Silicon_Sipper","Byte_Breeze","Data_Daiquiri","Algorithmic_Ambrosia"};
                ArrayAdapter ar = new ArrayAdapter(this, android.R.layout.simple_list_item_1, s);*/
                MainMenuRecyclerView = findViewById(R.id.recycleView);
                MainMenuAdapter recyclerViewMainMenuAdapter = new MainMenuAdapter(this);
                MainMenuRecyclerView.setAdapter(recyclerViewMainMenuAdapter);
                MainMenuRecyclerView.setLayoutManager(new LinearLayoutManager(this));

                /*ls.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Object o = ls.getItemAtPosition(position);

                    }
                });
                ls.setAdapter(ar);*/
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("konc");
    }
    public static void SendOut(int placement){
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("drink/make");
        ref.setValue(1);
        //int[][] out = new int[items.get(placement).size()][2];
        for (int i = 0; i < items.get(placement).size(); i++) {
            for (int j = 0; j < drinks.size(); j++) {
                if(items.get(placement).get(i).startsWith(drinks.get(j) + "~")){
                    ref = database.getReference("drink/" + j);
                    ref.setValue(Integer.parseInt(items.get(placement).get(i).split("~")[1]));
                    //out[i] = new int[]{j, Integer.parseInt(items.get(placement).get(i).split("~")[1])};
                    //out += "," + j + "," + items.get(placement).get(i).split("~")[1];
                    break;
                }
            }
        }
        //out = out.substring(1);
        try{
            /*final FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference ref = database.getReference("drink/make");
            ref.setValue(1);
            ref = database.getReference("drink/4" );
            ref.setValue(70);*/


            /*DatabaseReference orderRef = ref.child("make");
            ref.setValue(out);*/
            //System.out.println(out);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void SendAddDrink(String drink){
        System.out.println(drink);
    }
}
class DownloadFromAPI extends AsyncTask<String, String, String> {



    @Override
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL("https://iuz32hym3zxhbhaoykodt5vy6u0pczbn.lambda-url.eu-north-1.on.aws/calc?random=false&premade=false");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            String output;
            System.out.println("Output from Server .... \n");
            output = br.readLine();
            conn.disconnect();
            return output;
        }catch(Exception e){
            return "0";
        }
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        MainActivity.Instance.neki(s);
    }
}